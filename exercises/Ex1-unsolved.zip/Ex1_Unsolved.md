---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
    jupytext_version: 1.19.1
kernelspec:
  name: python3
  display_name: Python 3 (ipykernel)
  language: python
---

+++ {"toc": true}

<h1>Table of Contents<span class="tocSkip"></span></h1>
<div class="toc"><ul class="toc-item"><li><span><a href="#Basics" data-toc-modified-id="Basics-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>Basics</a></span><ul class="toc-item"><li><span><a href="#Custom-sensor-plugins-for-Mitsuba-3" data-toc-modified-id="Custom-sensor-plugins-for-Mitsuba-3-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>Custom sensor plugins for Mitsuba 3</a></span><ul class="toc-item"><li><span><a href="#Install-Mitsuba-3" data-toc-modified-id="Install-Mitsuba-3-1.1.1"><span class="toc-item-num">1.1.1&nbsp;&nbsp;</span>Install Mitsuba 3</a></span></li><li><span><a href="#Plugin-for-pinhole-camera" data-toc-modified-id="Plugin-for-pinhole-camera-1.1.2"><span class="toc-item-num">1.1.2&nbsp;&nbsp;</span>Plugin for pinhole camera</a></span></li><li><span><a href="#Plugin-for-thin-lens-camera" data-toc-modified-id="Plugin-for-thin-lens-camera-1.1.3"><span class="toc-item-num">1.1.3&nbsp;&nbsp;</span>Plugin for thin lens camera</a></span></li><li><span><a href="#Plugin-for-telecentric-camera" data-toc-modified-id="Plugin-for-telecentric-camera-1.1.4"><span class="toc-item-num">1.1.4&nbsp;&nbsp;</span>Plugin for telecentric camera</a></span></li></ul></li><li><span><a href="#Custom-emitter-plugins-for-Mitsuba" data-toc-modified-id="Custom-emitter-plugins-for-Mitsuba-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>Custom emitter plugins for Mitsuba</a></span><ul class="toc-item"><li><span><a href="#Plugin-for-telecentric-illumination" data-toc-modified-id="Plugin-for-telecentric-illumination-1.2.1"><span class="toc-item-num">1.2.1&nbsp;&nbsp;</span>Plugin for telecentric illumination</a></span></li></ul></li><li><span><a href="#Fourier-transform" data-toc-modified-id="Fourier-transform-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>Fourier transform</a></span><ul class="toc-item"><li><span><a href="#Convolution-in-the-Fourier-domain" data-toc-modified-id="Convolution-in-the-Fourier-domain-1.3.1"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>Convolution in the Fourier domain</a></span></li><li><span><a href="#Hybrid-images" data-toc-modified-id="Hybrid-images-1.3.2"><span class="toc-item-num">1.3.2&nbsp;&nbsp;</span>Hybrid images</a></span></li></ul></li></ul></li></ul></div>

+++

# Coding assignments

+++

## Fourier transform

+++

### Convolution in the Fourier domain

+++

Implement a function `fourier_conv(img:np.ndarray, kernel:np.ndarray) -> np.ndarray` that performs a 2D-convolution of the input image `img` with the convolution kernel `kernel` in the Fourier domain.

Validate via the function `np.allclose` and an example image that your result is equal to the result when performing the convolution in the spatial domain with `scipy.ndimage.convolve`.

```{code-cell} ipython3
import numpy as np
import scipy.ndimage as ndimage
from scipy.datasets import face
import matplotlib.pyplot as plt
```

```{code-cell} ipython3
def pad_like(inp : np.ndarray, like : np.ndarray):
    to_pad = tuple(np.int32((np.array(like.shape) - np.array(inp.shape))/2))
    return np.pad(inp, ((to_pad[0], to_pad[0]), (to_pad[1], to_pad[1])))
```

```{code-cell} ipython3
def fourier_conv(img:np.ndarray, kernel:np.ndarray) -> np.ndarray:
    
    result = np.zeros_like(img) ## replace with your solution
    
    return result
```

Test your function:

```{code-cell} ipython3
img = np.float32(face(gray=True))[0:-1, 0:-1]
kernel = np.ones((51,51))

res_fourier = fourier_conv(img, kernel)
res_spatial = ndimage.convolve(img, kernel, mode='wrap') ## Which mode do you have to use?

print(f"Is your solution correct: {np.allclose(res_fourier, res_spatial)}")

plt.figure()

plt.subplot(1,3,1)
plt.imshow(img, cmap='gray')
plt.subplot(1,3,2)
plt.imshow(res_spatial, cmap='gray')
plt.subplot(1,3,3)
plt.imshow(res_fourier, cmap='gray')
```

### Hybrid images

+++

Read the paper

*Hybrid images* by Aude Oliva et al. (https://dl.acm.org/doi/abs/10.1145/1141911.1141919).

Implement a function that takes two input images and combines them by high pass-filtering the first one and low pass-filtering the second one, so that in the resulting images, the first original image can be seen when viewing from a close distance and the second original image can be seen from a far distance.

+++

Some maybe helpful functions:

```{code-cell} ipython3
def make_odd_shapes(inp : np.ndarray) -> np.ndarray:
    if (inp.shape[0] % 2 == 0):
        inp = inp[0:-1,:]
    if (inp.shape[1] % 2 == 0):
        inp = inp[:,0:-1]
    return inp
```

```{code-cell} ipython3
def createPillobxResponse(r, x_size, y_size):
    X,Y = np.meshgrid(np.arange(-1*np.floor(x_size/2),np.floor(x_size/2)+1,1), np.arange(-1*np.floor(y_size/2),np.floor(y_size/2)+1,1))
    psf = np.zeros_like(X)
    psf[np.sqrt(X**2+Y**2) <= r] = 1
    return psf, X, Y
```

# Theory assignments

+++

## 1 — Thin lens: image distance and magnification

+++

A camera is modelled by a thin lens with focal length $f=50\,\mathrm{mm}$. An object of height $20\,\mathrm{mm}$ is placed at a distance $g=300\,\mathrm{mm}$ in front of the lens.

1. At what distance $b$ behind the lens must the sensor be placed to obtain a sharp image?
2. Calculate the magnification $V$ and the image height.
3. Sketch the image formation using a ray through the lens centre and a ray initially parallel to the optical axis. Indicate the image orientation.
4. The object is moved closer to the lens, to $g'=150\,\mathrm{mm}$. Where must the sensor now be placed? Does the image become larger or smaller? Calculate its new height.

Use the thin-lens equation:

$$
\frac{1}{f}=\frac{1}{g}+\frac{1}{b}.
$$

+++

## 2 — Defocus and stopping down

+++

The object remains at $g=300\,\mathrm{mm}$. However, the sensor is placed $\Delta b=0.12\,\mathrm{mm}$ farther behind the lens than the ideal image plane. The clear aperture diameter is $D=10\,\mathrm{mm}$.

1. Calculate the diameter $c$ of the circle of confusion using
   $$
   c=D\frac{|\Delta b|}{b},
   $$
   where $b$ is the ideal image distance from Exercise 1.
2. The sensor pixel pitch is $10\,\mu\mathrm{m}$. Express the circle-of-confusion diameter in pixel pitches.
3. The aperture diameter is reduced to $D'=5\,\mathrm{mm}$. How do the circle-of-confusion diameter and the amount of collected light change? Assume fixed exposure time and collected light proportional to aperture area.

+++

## 3 — Which systems are LSI?

+++

For each of the following systems, determine whether it is **linear** and whether it is **shift invariant**. Which systems are linear shift-invariant (LSI) systems?

Signals are real-valued and defined on all of $\mathbb R$; there are no image boundaries or cropping operations. The parameter $a$ is a fixed constant.

$$
\begin{aligned}
\mathscr S_1\{g\}(x)&=2g(x),\\
\mathscr S_2\{g\}(x)&=g(x)+1,\\
\mathscr S_3\{g\}(x)&=g(x)^2,\\
\mathscr S_4\{g\}(x)&=x\,g(x),\\
\mathscr S_5\{g\}(x)&=\tfrac12\bigl[g(x-a)+g(x+a)\bigr].
\end{aligned}
$$

Justify each decision using the definitions or a counterexample. A classification without a justification is not sufficient.

**Reminder:** Linearity requires

$$
\mathscr S\{\lambda g+\mu q\}(x)
=\lambda\mathscr S\{g\}(x)+\mu\mathscr S\{q\}(x)
$$

for all signals $g,q$ and real constants $\lambda,\mu$. Shift invariance requires

$$
\mathscr S\{g(\cdot-x_0)\}(x)
=\bigl(\mathscr S\{g\}\bigr)(x-x_0)
$$

for every shift $x_0$.

**Hint:** A linear system must satisfy $\mathscr S\{0\}=0$.

+++

## 4 — Impulse response and convolution

+++

An LSI system has the impulse response

$$
h(x)=\tfrac12\delta(x)+\tfrac12\delta(x-1).
$$

1. Express the output $k(x)$ in terms of an arbitrary input signal $g(x)$.
2. Calculate and sketch the output for
   $$
   g(x)=\delta(x)+2\delta(x-2).
   $$
   Label the positions and weights of all impulses. Arrows represent impulse weights, not finite function heights.
3. What happens to the output when the input from part 2 is shifted by three units in the positive $x$-direction? Give the new impulse positions.
4. What output results from the constant input $g(x)=1$, defined on all of $\mathbb R$?

Use

$$
k=g*h,\qquad g(x)*\delta(x-x_0)=g(x-x_0).
$$

+++

## 5 — A lens as an angular sensor

+++

A parallel ray bundle arrives at a lens with focal length $f=100\,\mathrm{mm}$ at an angle $\alpha$ to the optical axis. In the rear focal plane, its focal spot has displacement

$$
\delta_\alpha=f\tan(\alpha)
$$

from the optical axis. Treat the bundle as ideal, with a point-like focal spot.

1. The spot is displaced by $1\,\mathrm{mm}$. Calculate the magnitude of $\alpha$ in degrees.
2. A centred circular stop with opening radius $0.5\,\mathrm{mm}$ is placed in the rear focal plane. Up to what angle magnitude does it transmit the ray bundles?
3. Explain why this spatial stop acts as an angular filter. Which ray directions does a small centred opening preferentially transmit?

+++

## 6 — (Optional) MTF and image contrast

+++

An LSI imaging system has a real, positive optical transfer function at a spatial frequency $\nu_0>0$:

$$
H(\nu_0)=0.25.
$$

The impulse response is real, so $H(-\nu_0)=H(\nu_0)^*$, and the DC response is $H(0)=1$. The input signal is

$$
g(x)=1+0.8\cos(2\pi\nu_0x).
$$

1. Determine the output signal $k(x)$.
2. Calculate its maximum and minimum values.
3. Calculate the Michelson contrast of the input and output using
   $$
   C=\frac{\text{maximum}-\text{minimum}}{\text{maximum}+\text{minimum}}.
   $$
4. What would $H(\nu_0)=0$ mean for this input pattern?

**Hint:** In an LSI system, each spatial-frequency component is multiplied by the OTF at that frequency. The MTF is the magnitude of the OTF.
