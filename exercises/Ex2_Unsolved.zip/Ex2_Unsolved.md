---
jupytext:
  formats: ipynb,md:myst
  text_representation:
    extension: .md
    format_name: myst
    format_version: 0.13
    jupytext_version: 1.19.1
kernelspec:
  name: python3
  display_name: Python 3 (ipykernel)
  language: python
---

# Coding assignments

```{code-cell} ipython3
from __future__ import print_function
from ipywidgets import interact, interactive, fixed, interact_manual
import ipywidgets as widgets
import numpy as np
import matplotlib.pyplot as plt
import cv2
import scipy.signal as sig
from scipy.integrate import simpson
from IPython.display import SVG, display, IFrame, HTML
#%matplotlib notebook
%matplotlib widget
from scipy import ndimage
def imshow(img, cmap=None):
    plt.close('all')
    plt.figure()
    plt.imshow(img, cmap=cmap)
    plt.show()
```

## Light Field Methods

+++ {"slideshow": {"slide_type": "subslide"}}

### Reading and displaying light fields

+++

#### Get light field data

+++

Download the HCI light field dataset (see 'A dataset and evaluation methodology for depth estimation on 4D light fields' by Honauer et al.) from https://lightfield-analysis.uni-konstanz.de/

+++

#### Reading the light field

+++

Read light field from the bedroom scene from the HCI dataset and convert it into a 4D-structure `lf(m,n,j,k)` with `(m,n)` denoting the spatial coordinates and `(j,k)` denoting the angular coordinates.

+++

#### Displaying the center sub aperture image (SAI)

+++ {"slideshow": {"slide_type": "subslide"}}

Show center SAI for $\mathbf{j}=(4,4)^\intercal$:

+++

#### Display different SAIs

+++

Visualize how the perspective changes when the horizontal angular coordinate is changed continuosly.

+++

#### Synthesize a full aperture image

+++ {"slideshow": {"slide_type": "subslide"}}

Synthesize full aperture image, i.e., $g(\mathbf{m})=\sum\limits_{\mathbf{j}\in\Omega_\mathrm{a}} L(\mathbf{m},\mathbf{j})\,$:

+++

### Refocusing with light fields

+++ {"slideshow": {"slide_type": "subslide"}}

Define a refocus function `refocus(alpha)` by means of the shift and add-method as shown in the lecture.

+++

Hint: To realize the shift-operation, have a look at OpenCV whether there is a suitable function.

+++ {"slideshow": {"slide_type": "subslide"}}

Visualize the refocusing results for different $\alpha$:

+++

### Focus stack

+++

We will now calculate a single all-in-focus image of the observed scene.<br>
For that purpose, first create a stack of refocused images for the $\alpha$-values used above. Then try to filter each image of this series with a filter, that highlights sharp image regions, i.e., image regions with high spatial frequencies. For every pixel position, find the image inside the stack that is most sharp at that position. Eventually, extract for every pixel position the pixel value of the focal stack image that exhibits the highest sharpness for that position in order to obtain the all-in-focus image.

+++

# Theory assignments

+++

## 1 — Describing a light ray

+++

A ray travels towards a sensor in the plane $z=0$. It hits the sensor at $(x,y)=(2,1)\,\mathrm{mm}$ and previously crossed the plane $z=20\,\mathrm{mm}$ at $(u,v)=(6,1)\,\mathrm{mm}$.

1. Give the coordinates of the ray in the two-plane parameterization $L(x,y,u,v)$ and find its intersection with the plane halfway between the two planes.
2. A second ray hits the sensor at the same point but crosses the plane $z=20\,\mathrm{mm}$ at $(2,1)\,\mathrm{mm}$. How do the directions of the two rays differ? If an ordinary camera pixel at $(x,y)$ collects both rays, can its recorded value tell you how much light arrived from each direction? Explain.

+++

## 2 — Spatial and angular resolution of a light field camera

+++

A microlens array covers a sensor with $1200\times 800$ pixels. Each microlens covers a non-overlapping $4\times 4$ block of sensor pixels. Assume ideal alignment and use width $\times$ height throughout.

1. Determine the spatial resolution and the angular resolution of the sampled light field. What does changing the pixel position within a single block select?
2. Explain how to assemble one sub-aperture image (SAI) from the sensor pixels. How many different SAIs are available, and what is the size of each one?
3. Keep the same sensor, but use an array in which each microlens covers an $8\times 8$ block. How do the number and size of the SAIs change? Explain the trade-off in one sentence.

+++

## 3 — Refocusing by shift and add

+++

The table gives the horizontal pixel positions of two scene points, $A$ and $B$, in three sub-aperture images. Work in one dimension and ignore vertical shifts and image boundaries. A positive shift moves a feature to a larger pixel coordinate. Keep the centre SAI fixed.

| Scene point | Left SAI | Centre SAI | Right SAI |
| :--- | ---: | ---: | ---: |
| $A$ | 2 | 3 | 4 |
| $B$ | 6 | 8 | 10 |

1. By how many pixels should the left and right SAIs be shifted to align point $A$? Where does point $B$ appear in each of the shifted views?
2. Which shifts would align point $B$ instead? Why does adding the views after one set of shifts sharpen only one of the two points in this example?

+++

## 4 — Choosing an emission direction on a light field generator

+++

An ideal light field generator places a display in the focal plane of a microlens array. Consider one microlens with focal length $f_\mathrm{ML}=3.0\,\mathrm{mm}$ and a horizontal display pixel pitch of $60\,\mu\mathrm{m}$. Its calibrated central pixel is at column $u_0=20$. Assume all columns used in this exercise lie under this microlens, and treat each pixel as a point source at its centre.

Use the signed relation $\tan(\alpha)=\delta_\alpha/f_\mathrm{ML}$, with the angle sign chosen so that a positive offset $\delta_\alpha$ (increasing column index) gives a positive angle.

1. What is the emission direction of the central pixel? Why do the rays from one ideal point source form a parallel bundle after the microlens?
2. Calculate the emission angle when column 22 is activated. Which column would emit at the same angle magnitude but with the opposite sign?
3. Why is it useful to calibrate the central pixel separately for each microlens rather than assuming it always coincides with the nominal centre of its pixel block?

+++

## 5 — Weird light field generator emission?

+++

The following images (also shown in the lecture) are acquired for a light field display prototype with a total range of possible angles of $10^\circ$ in both directions. 

How can one explain the bottom right image?

+++

<img src="https://computational-imaging.de/book/figures/3/lfgCalibResults.svg">

+++

## 6 — Schlieren imaging

+++

In the lecture we learned:

+++

In a schlieren setup, a knife edge in the rear focal plane of the imaging lens blocks exactly half of the circular light source image when the rays are undeflected. Let $\varepsilon$ denote the diameter of the source image, and let $\delta_\alpha$ denote its signed displacement perpendicular to the knife edge due to a deflection angle $\alpha$. Assume that the rays are deflected only in this direction.

1. Explain why even a small displacement changes the amount of light that passes the knife edge.
2. Explain why the deflection angle can be uniquely inferred from a calibrated intensity measurement only for $|\delta_\alpha| < \varepsilon/2$. What happens at and beyond this limit?
